import { supabase } from "@/lib/supabase";
import ProductCard from "@/components/ProductCard";

export default function Home({ products }) {
  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-forest text-cream">
        <div className="mx-auto max-w-6xl px-5 py-20 sm:py-28 grid sm:grid-cols-2 gap-10 items-center">
          <div>
            <p className="text-turmeric font-semibold tracking-widest text-xs uppercase mb-4">
              India's Favourite Kitchen Gadgets
            </p>
            <h1 className="font-display text-4xl sm:text-5xl font-semibold leading-tight">
              Peel Smarter,
              <br />
              Not Harder.
            </h1>
            <p className="mt-5 text-cream/80 text-lg max-w-md">
              Rechargeable, safe, and built for every Indian kitchen. Prep faster
              and get back to what matters.
            </p>
            <a
              href="#shop"
              className="inline-block mt-8 rounded-full bg-turmeric px-8 py-3 font-semibold text-forest hover:bg-turmeric-light transition-colors"
            >
              Shop Now
            </a>
          </div>
          <div className="relative aspect-square rounded-blob bg-turmeric/10 border border-turmeric/20" />
        </div>
      </section>

      {/* Product grid */}
      <section id="shop" className="mx-auto max-w-6xl px-5 py-16">
        <h2 className="font-display text-3xl text-forest mb-8">Featured Products</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-5">
          {products?.length ? (
            products.map((p) => <ProductCard key={p.id} product={p} />)
          ) : (
            <p className="col-span-full text-charcoal/60">
              No products yet — add some in Supabase.
            </p>
          )}
        </div>
      </section>

      {/* FAQs */}
      <section id="faqs" className="bg-white/60 border-y border-forest/10">
        <div className="mx-auto max-w-3xl px-5 py-16">
          <h2 className="font-display text-3xl text-forest mb-8">FAQs</h2>
          <div className="space-y-6">
            <FaqItem
              q="Which fruits and vegetables can I peel with the Kivana Electric Peeler?"
              a="Almost everything — potatoes, sweet potatoes, carrots, beetroot, apples, pears, mangoes, cucumbers, zucchini, radish, turnip, raw papaya and more."
            />
            <FaqItem
              q="How do I charge the peeler?"
              a="Plug the included USB cable into any phone charger, laptop, or power bank. A full charge takes about 90 minutes and gives up to 60 minutes of continuous peeling."
            />
            <FaqItem
              q="Is it safe for children and elderly people to use?"
              a="Yes. It has a built-in safety lock and a finger guard, and requires zero force to operate."
            />
          </div>
        </div>
      </section>
    </div>
  );
}

function FaqItem({ q, a }) {
  return (
    <div className="border-b border-forest/10 pb-5">
      <h3 className="font-semibold text-forest">{q}</h3>
      <p className="mt-2 text-charcoal/70 text-sm">{a}</p>
    </div>
  );
}

export async function getServerSideProps() {
  const { data: products } = await supabase
    .from("products")
    .select("*")
    .eq("is_active", true)
    .order("created_at", { ascending: true });

  return {
    props: {
      products: products || [],
    },
  };
}

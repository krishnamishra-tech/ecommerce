import Link from "next/link";
import { useRouter } from "next/router";

export default function OrderSuccess() {
  const router = useRouter();
  const { orderId } = router.query;

  return (
    <div className="mx-auto max-w-2xl px-5 py-24 text-center">
      <div className="mx-auto h-16 w-16 rounded-full bg-turmeric flex items-center justify-center text-2xl font-bold text-forest">
        ✓
      </div>
      <h1 className="font-display text-3xl text-forest mt-6">Order Placed!</h1>
      <p className="mt-3 text-charcoal/70">
        Thank you for shopping with Kivana Home. We'll send updates on WhatsApp.
      </p>
      {orderId && (
        <p className="mt-2 text-sm text-charcoal/50">Order ID: {orderId}</p>
      )}
      <Link
        href="/"
        className="inline-block mt-8 rounded-full bg-turmeric px-8 py-3 font-semibold text-forest hover:bg-turmeric-light transition-colors"
      >
        Continue Shopping
      </Link>
    </div>
  );
}

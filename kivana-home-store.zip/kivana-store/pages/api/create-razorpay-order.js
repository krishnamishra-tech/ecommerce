import Razorpay from "razorpay";
import { createClient } from "@supabase/supabase-js";

// Server-side Supabase client — uses the service role key, never exposed to the browser
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET,
});

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  try {
    const { items, customer, total } = req.body;

    if (!items?.length || !customer?.name || !customer?.phone || !total) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    // Razorpay expects amount in paise
    const amountInPaise = Math.round(total * 100);

    const razorpayOrder = await razorpay.orders.create({
      amount: amountInPaise,
      currency: "INR",
      receipt: `kivana_${Date.now()}`,
    });

    // Save a pending order in Supabase
    const { data: order, error } = await supabaseAdmin
      .from("orders")
      .insert({
        razorpay_order_id: razorpayOrder.id,
        status: "pending",
        customer_name: customer.name,
        phone: customer.phone,
        email: customer.email || null,
        address_line: customer.address,
        city: customer.city,
        state: customer.state,
        pincode: customer.pincode,
        items,
        subtotal: total,
        total,
      })
      .select()
      .single();

    if (error) throw error;

    return res.status(200).json({
      razorpayOrderId: razorpayOrder.id,
      amount: amountInPaise,
      orderId: order.id,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Could not create order" });
  }
}

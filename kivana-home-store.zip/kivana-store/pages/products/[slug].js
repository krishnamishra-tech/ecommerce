import { useState } from "react";
import { useRouter } from "next/router";
import { supabase } from "@/lib/supabase";
import { useCart } from "@/lib/cart-context";

export default function ProductPage({ product }) {
  const router = useRouter();
  const { addItem } = useCart();
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);

  if (!product) {
    return (
      <div className="mx-auto max-w-3xl px-5 py-24 text-center">
        <p className="text-charcoal/60">Product not found.</p>
      </div>
    );
  }

  const hasDiscount =
    product.compare_at_price && product.compare_at_price > product.price;

  function handleAdd() {
    addItem(product, qty);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  }

  function handleBuyNow() {
    addItem(product, qty);
    router.push("/checkout");
  }

  return (
    <div className="mx-auto max-w-6xl px-5 py-12 grid sm:grid-cols-2 gap-12">
      <div className="aspect-square rounded-2xl overflow-hidden bg-white/60 border border-forest/10">
        {product.image_url && (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={product.image_url}
            alt={product.name}
            className="h-full w-full object-cover"
          />
        )}
      </div>

      <div>
        <h1 className="font-display text-3xl text-forest">{product.name}</h1>

        <div className="mt-3 flex items-baseline gap-3">
          <span className="text-2xl font-semibold text-forest">
            ₹{Number(product.price).toLocaleString("en-IN")}
          </span>
          {hasDiscount && (
            <span className="text-lg text-charcoal/40 line-through">
              ₹{Number(product.compare_at_price).toLocaleString("en-IN")}
            </span>
          )}
        </div>

        <p className="mt-5 text-charcoal/70 leading-relaxed">
          {product.description}
        </p>

        {product.stock > 0 ? (
          <>
            <div className="mt-6 flex items-center gap-4">
              <div className="flex items-center rounded-full border border-forest/20">
                <button
                  onClick={() => setQty((q) => Math.max(1, q - 1))}
                  className="px-4 py-2 text-forest font-semibold"
                >
                  −
                </button>
                <span className="px-3 font-medium text-forest">{qty}</span>
                <button
                  onClick={() => setQty((q) => q + 1)}
                  className="px-4 py-2 text-forest font-semibold"
                >
                  +
                </button>
              </div>
            </div>

            <div className="mt-6 flex flex-col sm:flex-row gap-3">
              <button
                onClick={handleAdd}
                className="rounded-full border-2 border-forest px-8 py-3 font-semibold text-forest hover:bg-forest hover:text-cream transition-colors"
              >
                {added ? "Added ✓" : "Add to Cart"}
              </button>
              <button
                onClick={handleBuyNow}
                className="rounded-full bg-turmeric px-8 py-3 font-semibold text-forest hover:bg-turmeric-light transition-colors"
              >
                Buy Now
              </button>
            </div>
          </>
        ) : (
          <p className="mt-6 font-semibold text-charcoal/60">
            Currently sold out — check back soon.
          </p>
        )}
      </div>
    </div>
  );
}

export async function getServerSideProps({ params }) {
  const { data: product } = await supabase
    .from("products")
    .select("*")
    .eq("slug", params.slug)
    .eq("is_active", true)
    .single();

  return {
    props: {
      product: product || null,
    },
  };
}

import Link from "next/link";
import { useCart } from "@/lib/cart-context";

export default function CartPage() {
  const { items, updateQty, removeItem, subtotal } = useCart();

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-2xl px-5 py-24 text-center">
        <h1 className="font-display text-3xl text-forest mb-4">Your cart is empty</h1>
        <Link
          href="/"
          className="inline-block mt-4 rounded-full bg-turmeric px-8 py-3 font-semibold text-forest hover:bg-turmeric-light transition-colors"
        >
          Continue Shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-5 py-12">
      <h1 className="font-display text-3xl text-forest mb-8">Your Cart</h1>

      <div className="space-y-4">
        {items.map((item) => (
          <div
            key={item.id}
            className="flex items-center gap-4 rounded-2xl border border-forest/10 bg-white/60 p-4"
          >
            <div className="h-20 w-20 rounded-xl overflow-hidden bg-cream flex-shrink-0">
              {item.image_url && (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={item.image_url}
                  alt={item.name}
                  className="h-full w-full object-cover"
                />
              )}
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-forest">{item.name}</h3>
              <p className="text-sm text-charcoal/60">
                ₹{item.price.toLocaleString("en-IN")}
              </p>
            </div>
            <div className="flex items-center rounded-full border border-forest/20">
              <button
                onClick={() => updateQty(item.id, item.qty - 1)}
                className="px-3 py-1 text-forest font-semibold"
              >
                −
              </button>
              <span className="px-2 font-medium text-forest">{item.qty}</span>
              <button
                onClick={() => updateQty(item.id, item.qty + 1)}
                className="px-3 py-1 text-forest font-semibold"
              >
                +
              </button>
            </div>
            <button
              onClick={() => removeItem(item.id)}
              className="text-sm text-charcoal/40 hover:text-red-600 transition-colors"
            >
              Remove
            </button>
          </div>
        ))}
      </div>

      <div className="mt-8 flex items-center justify-between border-t border-forest/10 pt-6">
        <span className="font-display text-xl text-forest">Subtotal</span>
        <span className="font-display text-xl text-forest">
          ₹{subtotal.toLocaleString("en-IN")}
        </span>
      </div>

      <Link
        href="/checkout"
        className="mt-6 block text-center rounded-full bg-turmeric px-8 py-3 font-semibold text-forest hover:bg-turmeric-light transition-colors"
      >
        Proceed to Checkout
      </Link>
    </div>
  );
}

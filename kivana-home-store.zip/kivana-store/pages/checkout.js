import { useState } from "react";
import { useRouter } from "next/router";
import Script from "next/script";
import { useCart } from "@/lib/cart-context";

export default function CheckoutPage() {
  const router = useRouter();
  const { items, subtotal, clearCart } = useCart();
  const [form, setForm] = useState({
    name: "",
    phone: "",
    email: "",
    address: "",
    city: "",
    state: "",
    pincode: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function handlePay(e) {
    e.preventDefault();
    setError("");

    if (items.length === 0) {
      setError("Your cart is empty.");
      return;
    }

    setLoading(true);
    try {
      // 1. Create order on the server (Razorpay order + Supabase row)
      const res = await fetch("/api/create-razorpay-order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ items, customer: form, total: subtotal }),
      });
      const data = await res.json();

      if (!res.ok) throw new Error(data.error || "Could not create order");

      // 2. Open Razorpay checkout
      const options = {
        key: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID,
        amount: data.amount,
        currency: "INR",
        name: "Kivana Home",
        description: "Order Payment",
        order_id: data.razorpayOrderId,
        prefill: {
          name: form.name,
          email: form.email,
          contact: form.phone,
        },
        theme: { color: "#1F3B2C" },
        handler: async function (response) {
          // 3. Verify payment on the server
          const verifyRes = await fetch("/api/verify-payment", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
              orderId: data.orderId,
            }),
          });
          const verifyData = await verifyRes.json();

          if (verifyRes.ok && verifyData.verified) {
            clearCart();
            router.push(`/order-success?orderId=${data.orderId}`);
          } else {
            setError("Payment verification failed. Please contact support.");
          }
        },
        modal: {
          ondismiss: function () {
            setLoading(false);
          },
        },
      };

      const rzp = new window.Razorpay(options);
      rzp.open();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <Script src="https://checkout.razorpay.com/v1/checkout.js" strategy="lazyOnload" />
      <div className="mx-auto max-w-3xl px-5 py-12">
        <h1 className="font-display text-3xl text-forest mb-8">Checkout</h1>

        <form onSubmit={handlePay} className="grid sm:grid-cols-2 gap-4">
          <Input label="Full Name" name="name" value={form.name} onChange={handleChange} required className="sm:col-span-2" />
          <Input label="Phone Number" name="phone" value={form.phone} onChange={handleChange} required />
          <Input label="Email (optional)" name="email" type="email" value={form.email} onChange={handleChange} />
          <Input label="Address" name="address" value={form.address} onChange={handleChange} required className="sm:col-span-2" />
          <Input label="City" name="city" value={form.city} onChange={handleChange} required />
          <Input label="State" name="state" value={form.state} onChange={handleChange} required />
          <Input label="Pincode" name="pincode" value={form.pincode} onChange={handleChange} required />

          <div className="sm:col-span-2 mt-4 rounded-2xl border border-forest/10 bg-white/60 p-5">
            <div className="flex justify-between text-charcoal/70 text-sm mb-2">
              <span>{items.length} item(s)</span>
              <span>₹{subtotal.toLocaleString("en-IN")}</span>
            </div>
            <div className="flex justify-between font-display text-lg text-forest border-t border-forest/10 pt-3">
              <span>Total</span>
              <span>₹{subtotal.toLocaleString("en-IN")}</span>
            </div>
          </div>

          {error && <p className="sm:col-span-2 text-red-600 text-sm">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="sm:col-span-2 rounded-full bg-turmeric px-8 py-3 font-semibold text-forest hover:bg-turmeric-light transition-colors disabled:opacity-50"
          >
            {loading ? "Processing..." : "Pay with Razorpay"}
          </button>
        </form>
      </div>
    </>
  );
}

function Input({ label, className = "", ...props }) {
  return (
    <label className={`block text-sm font-medium text-forest ${className}`}>
      {label}
      <input
        {...props}
        className="mt-1 w-full rounded-lg border border-forest/20 bg-white px-4 py-2 text-charcoal focus:border-turmeric focus:outline-none"
      />
    </label>
  );
}

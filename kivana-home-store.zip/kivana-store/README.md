# Kivana Home — Apna Ecommerce Store

Next.js + Supabase + Razorpay se bana hua, poora functional ecommerce store. Isko Vercel pe deploy karoge (jaisa Lead Hunter tool kiya tha), waise hi.

## Kya-kya hai isme

- Homepage with hero + product grid (Supabase se live data)
- Product detail page
- Cart (localStorage mein save hota hai)
- Checkout page with **real Razorpay payment**
- Payment verify hone ke baad order Supabase mein save hota hai
- Order success page

## Setup — Step by Step

### 1. Supabase Project Banao (agar pehle se nahi hai)
1. https://supabase.com pe jao, naya project banao.
2. **SQL Editor** mein jaake `supabase/schema.sql` file ka poora content paste karo aur Run karo. Isse `products` aur `orders` table ban jayengi, aur 2 starter products (Peeler + Scrubber) bhi add ho jayenge.
3. **Project Settings > API** mein jaake ye 3 cheezein copy karo:
   - Project URL
   - `anon` `public` key
   - `service_role` key (ye secret hai, kisi ko mat dena)

### 2. Razorpay Account Banao
1. https://razorpay.com pe signup karo (business KYC lagega live payments ke liye — shuru mein **Test Mode** use karo).
2. Dashboard > **Settings > API Keys** mein jaake Test Key ID aur Key Secret generate karo.
3. Jab business ready ho to KYC complete karke Live keys use karna.

### 3. Local Setup (apne computer pe test karne ke liye — optional)
```bash
cd kivana-store
npm install
cp .env.example .env.local
# .env.local file kholo aur apni Supabase + Razorpay keys daalo
npm run dev
```
Browser mein `http://localhost:3000` khol ke dekh sakte ho.

### 4. Vercel pe Deploy karo (jaisa Lead Hunter tool kiya tha)
1. Is poore code ko GitHub repo mein push karo.
2. https://vercel.com pe jaake "New Project" > apna GitHub repo select karo.
3. Deploy karne se pehle **Environment Variables** section mein `.env.example` mein di gayi saari keys add karo (apni real values ke saath).
4. Deploy karo. 2-3 minute mein live ho jayega.
5. Baad mein apna custom domain (jaise kivanahome.in) bhi Vercel se connect kar sakte ho.

## Products Add/Edit karna

Supabase Dashboard > **Table Editor > products** mein jaake seedha row add/edit kar sakte ho — naya product, price change, stock update, sab UI se ho jayega, code chhedne ki zaroorat nahi.

## Orders Dekhna

Supabase Dashboard > **Table Editor > orders** mein saare orders dikhenge — customer detail, address, items, payment status sab kuch.

## Important Notes

- **Test Mode se shuru karo.** Razorpay Test keys se pehle poora flow check kar lo (test card numbers Razorpay docs mein milte hain), phir Live keys pe switch karna.
- **Service role key kabhi bhi frontend code ya GitHub public repo mein mat daalna** — sirf Vercel ke Environment Variables mein.
- Jab tak Razorpay KYC/live approval nahi hota, real customers se payment nahi le paoge — usse pehle Test mode mein sab verify kar lena.
- WhatsApp number aur email `components/Footer.js` mein apna daal dena.
- Product images abhi Shopify store se hi link ki hain — apni photos Supabase Storage ya kahin aur host karke `image_url` update kar sakte ho.

## Agla Kadam

Store ready hone ke baad Phase 1 (organic traction) wala roadmap follow karo jo pehle banaya tha — reels, WhatsApp outreach, aur influencer barter se pehle orders laao, phir paid ads test karo.

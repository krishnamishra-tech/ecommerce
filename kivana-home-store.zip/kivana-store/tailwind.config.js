/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./pages/**/*.{js,jsx}",
    "./components/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      colors: {
        forest: {
          DEFAULT: "#1F3B2C",
          light: "#2E5541",
          dark: "#122318",
        },
        turmeric: {
          DEFAULT: "#E8A93D",
          light: "#F2C367",
          dark: "#C88A22",
        },
        cream: "#FBF7EE",
        charcoal: "#20201C",
      },
      fontFamily: {
        display: ["'Fraunces'", "serif"],
        body: ["'Inter'", "sans-serif"],
      },
      borderRadius: {
        blob: "40% 60% 60% 40% / 50% 40% 60% 50%",
      },
    },
  },
  plugins: [],
};

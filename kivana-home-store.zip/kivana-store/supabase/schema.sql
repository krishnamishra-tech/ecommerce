-- Kivana Home — Supabase Schema
-- Run this in Supabase SQL Editor (Project > SQL Editor > New Query)

create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  description text,
  price numeric(10,2) not null,
  compare_at_price numeric(10,2),
  image_url text,
  gallery_urls text[],
  stock integer not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  razorpay_order_id text unique,
  razorpay_payment_id text,
  status text not null default 'pending', -- pending | paid | failed | shipped | delivered
  customer_name text not null,
  phone text not null,
  email text,
  address_line text not null,
  city text not null,
  state text,
  pincode text not null,
  items jsonb not null,          -- [{product_id, name, price, qty}]
  subtotal numeric(10,2) not null,
  total numeric(10,2) not null,
  created_at timestamptz not null default now()
);

-- Enable Row Level Security
alter table products enable row level security;
alter table orders enable row level security;

-- Anyone can read active products (public storefront)
create policy "Public can view active products"
  on products for select
  using (is_active = true);

-- Orders: allow inserts from the storefront (anon key), no public read
-- (order lookups should go through a server-side API route, not direct client reads)
create policy "Public can insert orders"
  on orders for insert
  with check (true);

-- Seed data — Kivana Home starter catalog
insert into products (slug, name, description, price, compare_at_price, image_url, stock)
values
  (
    'automatic-fruit-vegetable-peeler',
    'Automatic Fruit & Vegetable Peeler',
    'Rechargeable electric peeler with 5 interchangeable blades. Peels potatoes, carrots, apples, mangoes and more in seconds. Built-in safety lock and finger guard.',
    1349.00,
    2399.00,
    'https://6cdfuk-rg.myshopify.com/cdn/shop/files/71XyOtjOy3L._SL1500.jpg',
    50
  ),
  (
    '5-in-1-power-scrubber',
    '5-in-1 Magic Power Scrubber',
    'Handheld electric cleaning brush with 360-degree spin and 3 interchangeable brush heads. Perfect for showers, bathrooms, and kitchen surfaces.',
    899.00,
    1499.00,
    'https://6cdfuk-rg.myshopify.com/cdn/shop/files/61y6EVolm0L._SL1496.jpg',
    30
  )
on conflict (slug) do nothing;

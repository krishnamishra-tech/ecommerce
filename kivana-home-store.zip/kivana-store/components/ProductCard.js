import Link from "next/link";

export default function ProductCard({ product }) {
  const hasDiscount =
    product.compare_at_price && product.compare_at_price > product.price;
  const discountPct = hasDiscount
    ? Math.round(
        ((product.compare_at_price - product.price) / product.compare_at_price) * 100
      )
    : 0;

  return (
    <Link
      href={`/products/${product.slug}`}
      className="group block rounded-2xl bg-white/60 border border-forest/10 overflow-hidden hover:shadow-lg hover:-translate-y-1 transition-all duration-300"
    >
      <div className="relative aspect-square overflow-hidden bg-cream">
        {product.image_url && (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={product.image_url}
            alt={product.name}
            className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        )}
        {hasDiscount && (
          <span className="absolute top-3 left-3 rounded-full bg-turmeric px-3 py-1 text-xs font-bold text-forest">
            {discountPct}% OFF
          </span>
        )}
        {product.stock <= 0 && (
          <span className="absolute inset-0 flex items-center justify-center bg-forest/50 text-cream font-semibold">
            Sold Out
          </span>
        )}
      </div>
      <div className="p-4">
        <h3 className="font-display text-lg text-forest leading-snug">
          {product.name}
        </h3>
        <div className="mt-2 flex items-baseline gap-2">
          <span className="font-semibold text-forest">
            ₹{Number(product.price).toLocaleString("en-IN")}
          </span>
          {hasDiscount && (
            <span className="text-sm text-charcoal/40 line-through">
              ₹{Number(product.compare_at_price).toLocaleString("en-IN")}
            </span>
          )}
        </div>
      </div>
    </Link>
  );
}

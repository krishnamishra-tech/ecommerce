export default function Footer() {
  return (
    <footer className="bg-forest text-cream mt-20">
      <div className="mx-auto max-w-6xl px-5 py-12 grid gap-8 sm:grid-cols-3">
        <div>
          <h3 className="font-display text-xl mb-2">Kivana Home</h3>
          <p className="text-sm text-cream/70">
            Making every Indian kitchen smarter, faster, and more joyful — one gadget at a time.
          </p>
        </div>
        <div>
          <h4 className="text-sm font-semibold uppercase tracking-wide text-turmeric mb-3">
            Store
          </h4>
          <ul className="space-y-2 text-sm text-cream/80">
            <li>Shipping Policy</li>
            <li>Refund Policy</li>
            <li>Terms of Service</li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-semibold uppercase tracking-wide text-turmeric mb-3">
            Contact
          </h4>
          <p className="text-sm text-cream/80">WhatsApp: +91 XXXXX XXXXX</p>
          <p className="text-sm text-cream/80">support@kivanahome.in</p>
        </div>
      </div>
      <div className="border-t border-cream/10 py-4 text-center text-xs text-cream/50">
        © {new Date().getFullYear()} Kivana Home. All rights reserved.
      </div>
    </footer>
  );
}

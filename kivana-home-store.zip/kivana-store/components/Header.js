import Link from "next/link";
import { useCart } from "@/lib/cart-context";

export default function Header() {
  const { count } = useCart();

  return (
    <header className="sticky top-0 z-40 bg-cream/90 backdrop-blur border-b border-forest/10">
      <div className="mx-auto max-w-6xl px-5 py-4 flex items-center justify-between">
        <Link href="/" className="font-display text-2xl font-semibold text-forest tracking-tight">
          Kivana <span className="text-turmeric-dark">Home</span>
        </Link>

        <nav className="hidden sm:flex items-center gap-8 font-body text-sm font-medium text-forest">
          <Link href="/" className="hover:text-turmeric-dark transition-colors">Shop</Link>
          <Link href="/#faqs" className="hover:text-turmeric-dark transition-colors">FAQs</Link>
        </nav>

        <Link
          href="/cart"
          className="relative flex items-center gap-2 rounded-full border border-forest/20 px-4 py-2 text-sm font-medium text-forest hover:bg-forest hover:text-cream transition-colors"
        >
          Cart
          {count > 0 && (
            <span className="absolute -top-2 -right-2 flex h-5 w-5 items-center justify-center rounded-full bg-turmeric text-[11px] font-bold text-forest">
              {count}
            </span>
          )}
        </Link>
      </div>
    </header>
  );
}
